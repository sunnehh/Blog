/*********************************************************************************
 * BTI425 – Assignment 03
 * I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part of this
 * assignment has been copied manually or electronically from any other source (including web sites) or
 * distributed to other students.
 *
 * Name: Sunny Qi Student ID: 136570207 Date: March 24 2022
 *
 ********************************************************************************/

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'bti425-a3-sunny';
}
