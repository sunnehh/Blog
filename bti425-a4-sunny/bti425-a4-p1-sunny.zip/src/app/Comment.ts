export interface Comment {
  author: string;
  comment: string;
  date: string;
}
