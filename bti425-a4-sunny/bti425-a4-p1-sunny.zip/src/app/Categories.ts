export interface category {
  cat: string;
  num: number;
}
